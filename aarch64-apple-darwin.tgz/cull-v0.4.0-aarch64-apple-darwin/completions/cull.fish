complete -c cull -s a -l attr -d 'Print an attribute of each match' -r
complete -c cull -s j -l json -d 'Shape matches into JSON via a template, e.g. \'{title: h2, url: a @href, tags: [.tag]}\'' -r
complete -c cull -s r -l remove -d 'Remove nodes matching this CSS selector before selecting/output (repeatable; comma lists work: --remove \'nav, footer, script\')' -r
complete -c cull -s b -l base -d 'Resolve relative URLs in href/src against this base' -r
complete -c cull -l color -d 'Colorize HTML output: auto (default; TTY only), always, never' -r -f -a "auto\t''
always\t''
never\t''"
complete -c cull -l completions -d 'Generate shell completions (bash, zsh, fish, elvish, powershell) and exit' -r -f -a "bash\t''
elvish\t''
fish\t''
powershell\t''
zsh\t''"
complete -c cull -s t -l text -d 'Print collapsed text content of matches'
complete -c cull -l table -d 'Extract tables as CSV (or NDJSON with --json-rows)'
complete -c cull -l json-rows -d 'With --table: emit one JSON object per row, keyed by header'
complete -c cull -l md -d 'Convert matches (or the document) to Markdown'
complete -c cull -s 1 -l first -d 'Only output the first match'
complete -c cull -l array -d 'Wrap --json output in a single JSON array instead of NDJSON'
complete -c cull -s p -l pretty -d 'Pretty-print output: indented HTML, or indented JSON with --json/--table'
complete -c cull -s c -l count -d 'Print only the number of matches (like grep -c)'
complete -c cull -l man -d 'Print a roff man page to stdout and exit (e.g. `cull --man > cull.1`)'
complete -c cull -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cull -s V -l version -d 'Print version'
