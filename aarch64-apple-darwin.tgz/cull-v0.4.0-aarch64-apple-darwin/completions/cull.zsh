#compdef cull

autoload -U is-at-least

_cull() {
    typeset -A opt_args
    typeset -a _arguments_options
    local ret=1

    if is-at-least 5.2; then
        _arguments_options=(-s -S -C)
    else
        _arguments_options=(-s -C)
    fi

    local context curcontext="$curcontext" state line
    _arguments "${_arguments_options[@]}" : \
'-a+[Print an attribute of each match]:NAME:_default' \
'--attr=[Print an attribute of each match]:NAME:_default' \
'-j+[Shape matches into JSON via a template, e.g. '\''{title\: h2, url\: a @href, tags\: \[.tag\]}'\'']:TEMPLATE:_default' \
'--json=[Shape matches into JSON via a template, e.g. '\''{title\: h2, url\: a @href, tags\: \[.tag\]}'\'']:TEMPLATE:_default' \
'*-r+[Remove nodes matching this CSS selector before selecting/output (repeatable; comma lists work\: --remove '\''nav, footer, script'\'')]:SELECTOR:_default' \
'*--remove=[Remove nodes matching this CSS selector before selecting/output (repeatable; comma lists work\: --remove '\''nav, footer, script'\'')]:SELECTOR:_default' \
'-b+[Resolve relative URLs in href/src against this base]:URL:_default' \
'--base=[Resolve relative URLs in href/src against this base]:URL:_default' \
'--color=[Colorize HTML output\: auto (default; TTY only), always, never]:WHEN:(auto always never)' \
'--completions=[Generate shell completions (bash, zsh, fish, elvish, powershell) and exit]:SHELL:(bash elvish fish powershell zsh)' \
'-t[Print collapsed text content of matches]' \
'--text[Print collapsed text content of matches]' \
'--table[Extract tables as CSV (or NDJSON with --json-rows)]' \
'--json-rows[With --table\: emit one JSON object per row, keyed by header]' \
'--md[Convert matches (or the document) to Markdown]' \
'-1[Only output the first match]' \
'--first[Only output the first match]' \
'--array[Wrap --json output in a single JSON array instead of NDJSON]' \
'-p[Pretty-print output\: indented HTML, or indented JSON with --json/--table]' \
'--pretty[Pretty-print output\: indented HTML, or indented JSON with --json/--table]' \
'-c[Print only the number of matches (like grep -c)]' \
'--count[Print only the number of matches (like grep -c)]' \
'--man[Print a roff man page to stdout and exit (e.g. \`cull --man > cull.1\`)]' \
'-h[Print help (see more with '\''--help'\'')]' \
'--help[Print help (see more with '\''--help'\'')]' \
'-V[Print version]' \
'--version[Print version]' \
'::selector -- CSS selector (omit with --table/--md to use the whole document):_default' \
'::input -- Input file or URL (default\: stdin):_default' \
&& ret=0
}

(( $+functions[_cull_commands] )) ||
_cull_commands() {
    local commands; commands=()
    _describe -t commands 'cull commands' commands "$@"
}

if [ "$funcstack[1]" = "_cull" ]; then
    _cull "$@"
else
    compdef _cull cull
fi
